package ru.mrs.ws.client.soap.simple;

import ru.mrs.ws.client.soap.simple.dev.Currency;

// https://www.baeldung.com/java-soap-web-service
// https://spring.io/guides/gs/consuming-web-service/

public class Main {
    @Before//Class
    public static void setup() {
        CountryServiceImplService service = new CountryServiceImplService();
        CountryService countryService = service.getCountryServiceImplPort();
    }

    @Test
    public void givenCountryService_whenCountryIndia_thenCapitalIsNewDelhi() {
        assertEquals("New Delhi", countryService.findByName("India").getCapital());
    }

    @Test
    public void givenCountryService_whenCountryFrance_thenPopulationCorrect() {
        assertEquals(66710000, countryService.findByName("France").getPopulation());
    }

    @Test
    public void givenCountryService_whenCountryUSA_thenCurrencyUSD() {
        assertEquals(Currency.USD, countryService.findByName("USA").getCurrency());
    }
}
